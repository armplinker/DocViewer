﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Telerik.Web.Design;

namespace DocViewer.App_Code
{
    public partial class DocumentTypePanelBar1 :  UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}